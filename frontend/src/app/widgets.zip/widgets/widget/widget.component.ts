import {Component, EventEmitter, Input, OnInit, Output, ViewChild, ViewContainerRef} from '@angular/core';

@Component({
    selector: 'widget',
    templateUrl: './widget.component.html',
    styleUrls: ['./widget.component.scss'],
})
export class WidgetComponent implements OnInit {
    @ViewChild('widget', { read: ViewContainerRef, static: true })
    widgetBody: ViewContainerRef;

    @Input() data: string;

    @Output() emit: EventEmitter<string> = new EventEmitter<string>();

    ngOnInit() {
        this.widgetBody.element.nativeElement.addEventListener('click', () => {
            this.emit.emit(this.data);
        });
    }
}
