import {Component, OnInit} from '@angular/core';

const widgetsNumber = 13;

const toDownMap: Map<number, number> = new Map<number, number>([
   [1, 4],
   [2, 9],
   [3, 7],
   [4, 11],
   [5, 8],
   [6, 10],
   [7, 10],
   [8, 12],
   [9, 13],
   [10, 13],
   [11, 11],
   [12, 12],
   [13, 13],
]);

const toUpMap: Map<number, number> = new Map<number, number>([
    [1, 1],
    [2, 2],
    [3, 3],
    [4, 1],
    [5, 2],
    [6, 2],
    [7, 3],
    [8, 5],
    [9, 2],
    [10, 6],
    [11, 4],
    [12, 8],
    [13, 10],
]);

@Component({
    selector: 'widgets-header',
    templateUrl: './widgets.component.html',
    styleUrls: ['./widgets.component.scss'],
})
export class WidgetsComponent implements OnInit {
    current: number;

    dataMap: Map<number, string>;

    ngOnInit() {
        this.dataMap = new Map<number, string>([
            [1, '1'],
            [2, '2'],
            [3, '3'],
            [4, '4'],
            [5, '5'],
            [6, '6'],
            [7, '7'],
            [8, '8'],
            [9, '9'],
            [10, '10'],
            [11, '11'],
            [12, '12'],
            [13, '13'],
        ]);

        this.current = 1;

        document.addEventListener('keydown', event => {
            switch (event.code) {
                case 'ArrowRight':
                    this.toRight();
                    break;
                case 'ArrowLeft':
                    this.toLeft();
                    break;
                case 'ArrowDown':
                    this.toDown();
                    break;
                case 'ArrowUp':
                    this.toUp();
                    break;
                case 'Enter':
                    this.print(this.dataMap.get(this.current));
                    break;
            }
        });
    }

    print(data: string): void {
        console.log('Click at rect ' + data);
    }

    private toRight(): void {
        if (this.current === widgetsNumber) {
            return;
        }

        this.current++;
    }

    private toLeft(): void {
        if (this.current === 1) {
            return;
        }

        this.current--;
    }

    private toDown(): void {
        this.current = toDownMap.get(this.current);
    }
    private toUp(): void {
        this.current = toUpMap.get(this.current);
    }
}
